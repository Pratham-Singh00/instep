<?php
/**
 * Team Page Template - Hardcoded team members
 */
get_header();
?>

<main>
    <section class="py-16 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 text-blue-600">Our Team</h1>
            <p class="text-gray-600 max-w-3xl mx-auto text-lg">
                Meet our dedicated team of licensed professionals who are committed to providing compassionate, evidence-based mental health care to our community.
            </p>
        </div>
    </section>

    <section class="py-16 max-w-7xl mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <!-- Cathi Cohen -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-blue-600 to-blue-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Cathi Cohen</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Founder & Clinical Director</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">LCSW</span>
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">CGP</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">40+ years creating In Step and leading group therapy programs.</p>
                    <a href="mailto:cathi@insteppc.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Dale Sorg -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-green-600 to-green-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Dale Sorg</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Licensed School Psychologist</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">M.A.</span>
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">Ed.S</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Passionate about early childhood development and social skills.</p>
                    <a href="mailto:psychologistdale@gmail.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Erika Carlson -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-purple-600 to-purple-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Erika Carlson</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Licensed Clinical Social Worker</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">LCSW</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Specializes in DBT and emotion regulation for adolescents and adults.</p>
                    <a href="mailto:ejbcarlson@gmail.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Christina Marcone -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-pink-600 to-pink-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Christina Marcone</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Licensed Clinical Social Worker</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">LCSW</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Trauma-informed approach with deep commitment to client potential.</p>
                    <a href="mailto:christina@insteppc.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Jim Sebben -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-red-600 to-red-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Jim Sebben</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Counselor & Marriage/Family Therapist</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">EdD</span>
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">LPC</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">38+ years in private practice, expertise in ADHD & addiction recovery.</p>
                    <a href="mailto:jsebben2@gmail.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Kimberley Grimes -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-indigo-600 to-indigo-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Kimberley Grimes</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Licensed Clinical Social Worker</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">LCSW</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Leads social skills groups and offers SPACE program for anxious children.</p>
                    <a href="mailto:kimglcsw@gmail.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Dov Cohen -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-cyan-600 to-cyan-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Dov Cohen</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Clinical Social Worker (Supervisee)</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">MSW</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Passionate about connecting with youth. Creator of D&D social group.</p>
                    <a href="mailto:dov@insteppc.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Kelly Murphy -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-amber-600 to-amber-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Kelly Murphy</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Licensed Professional Counselor</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">LPC</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Treats behavioral challenges, anxiety, and social difficulties in youth.</p>
                    <a href="mailto:kmw192@gmail.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Salima Jiwa -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-teal-600 to-teal-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Salima Jiwa</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Licensed Clinical Social Worker</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">LCSW</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Co-facilitates DBT Skills Training and offers parent coaching.</p>
                    <a href="mailto:sjiwa00@gmail.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Rachel Cherian -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-lime-600 to-lime-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Rachel Cherian</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Licensed Clinical Social Worker</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">LCSW</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">20+ years experience. Specializes in DBT and cultural competence.</p>
                    <a href="mailto:rachelcherian.lcsw@gmail.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Keith Ewell -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-sky-600 to-sky-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Keith K. Ewell</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Licensed Clinical Psychologist</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">Ph.D.</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">25+ years with In Step. Expert in anxiety, ADHD, and medical issues.</p>
                    <a href="mailto:" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Erica Craig-Mann -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-violet-600 to-violet-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Erica Craig-Mann</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">Clinical Social Worker & Drama Therapist</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">Ph.D.</span>
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">RDT-BCT</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Innovative drama therapy approaches. Virtual only therapist.</p>
                    <a href="mailto:erica@insteppc.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>

            <!-- Zara Ahmad -->
            <div class="bg-white rounded-lg shadow hover:shadow-lg transition">
                <div class="bg-gradient-to-r from-rose-600 to-rose-400 h-40"></div>
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-900">Zara Ahmad</h3>
                    <p class="text-sm text-blue-600 font-semibold mb-2">School Psychologist</p>
                    <div class="flex flex-wrap gap-1 mb-3">
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">M.A.</span>
                        <span class="bg-gray-200 text-gray-800 px-2 py-1 text-xs rounded">NCSP</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Works with children on the spectrum. Compassionate and dedicated.</p>
                    <a href="mailto:zara@insteppc.com" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">Contact →</a>
                </div>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();
?>
