<?php
/**
 * In Step Community Connect - Minimal Theme
 */

if (!defined('ABSPATH')) {
    exit;
}

define('INSTEP_THEME_VERSION', '1.0.0');

/**
 * Theme setup
 */
function instep_theme_setup(): void {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
}
add_action('after_setup_theme', 'instep_theme_setup');

/**
 * Enqueue styles
 */
function instep_enqueue_assets(): void {
    wp_enqueue_style('instep-style', get_stylesheet_uri(), array(), INSTEP_THEME_VERSION);
    wp_enqueue_style('instep-responsive', get_template_directory_uri() . '/responsive.css', array(), INSTEP_THEME_VERSION);
}
add_action('wp_enqueue_scripts', 'instep_enqueue_assets');

/**
 * Register contact request CPT
 */
function instep_register_cpts(): void {
    register_post_type('contact_request', array(
        'labels' => array(
            'name' => 'Contact Requests',
            'singular_name' => 'Contact Request',
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 25,
        'supports' => array('title', 'editor'),
        'menu_icon' => 'dashicons-email',
    ));
}
add_action('init', 'instep_register_cpts');
