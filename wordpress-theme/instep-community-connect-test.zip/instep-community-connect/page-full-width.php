<?php
/**
 * Template Name: Full Width
 * Template Post Type: page
 *
 * A full-width page template with no sidebars
 *
 * @package InStepCommunityConnect
 * @since 1.0.0
 */

get_header();
?>

<div id="instep-community-connect-root"></div>

<?php
get_footer();
