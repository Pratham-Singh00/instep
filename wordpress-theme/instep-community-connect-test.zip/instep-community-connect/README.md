# In Step Community Connect WordPress Theme

A modern, responsive WordPress theme for In Step Community Connect featuring a React-based single-page application design.

## Description

This theme provides a comprehensive platform for community engagement, services showcase, and contact management. It features a modern React-based frontend with WordPress integration for content management.

## Features

- **Fully Responsive Design**: Works perfectly on all devices (mobile, tablet, desktop)
- **React-Based Frontend**: Modern, fast, and interactive user interface
- **WordPress Content Management**: Easy-to-use admin interface for content updates
- **RESTful API Integration**: Seamless communication between WordPress and React
- **Customizable Content**: JSON-based content system with visual editor
- **Accessibility Ready**: WCAG 2.1 Level AA compliant
- **SEO Optimized**: Clean markup and proper semantic structure
- **Performance Optimized**: Fast loading times with optimized assets

## Requirements

- **WordPress**: 6.0 or higher
- **PHP**: 8.3 or higher (minimum recommended version)
- **MySQL**: 5.7 or higher / MariaDB 10.3 or higher

## Installation

1. Download the theme ZIP file
2. Go to WordPress Admin → Appearance → Themes → Add New
3. Click "Upload Theme" and select the ZIP file
4. Click "Install Now"
5. After installation, click "Activate"

## Manual Installation

1. Extract the ZIP file
2. Upload the `instep-community-connect` folder to `/wp-content/themes/`
3. Go to WordPress Admin → Appearance → Themes
4. Find "In Step Community Connect" and click "Activate"

## Configuration

### Content Management

1. After activating the theme, go to **In Step Content** in the WordPress admin menu
2. Use the **Quick Settings** section for common edits:
   - Primary Phone Number
   - Hero Section Text
   - Contact Information
   - Footer Text
3. For advanced customization, use the **JSON Editor** to modify all content

### Menus

1. Go to Appearance → Menus
2. Create menus for:
   - Primary Menu (main navigation)
   - Footer Menu (footer links)

### Customization

1. Go to Appearance → Customize
2. Configure:
   - Site Identity (logo, site title, tagline)
   - Colors
   - Additional CSS if needed

## Theme Structure

```
instep-community-connect/
├── assets/
│   ├── admin.css              # Admin panel styles
│   └── build/                 # Built React application
│       ├── assets/            # JS, CSS, and images
│       └── .vite/            # Vite manifest
├── data/
│   └── default-content.json  # Default content structure
├── includes/
│   └── class-instep-theme.php # Main theme class
├── footer.php                 # Footer template
├── functions.php              # Theme functions
├── header.php                 # Header template
├── index.php                  # Main template
├── style.css                  # Theme stylesheet (required)
├── screenshot.png             # Theme screenshot
└── README.md                  # This file
```

## REST API Endpoints

The theme registers the following REST API endpoints:

- `GET /wp-json/instep/v1/content` - Returns full site content
- `GET /wp-json/instep/v1/team` - Returns team member data
- `GET /wp-json/wp/v2/posts` - Standard WordPress posts (for blog)

## Responsive Design

The theme is fully responsive and tested on:

- **Mobile**: 320px - 767px
- **Tablet**: 768px - 1024px
- **Desktop**: 1025px and above

All content is optimized for touch interfaces and various screen sizes.

## Browser Support

- Chrome (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Edge (latest 2 versions)
- Mobile Safari (iOS 12+)
- Chrome for Android (latest)

## Content Schema

The theme uses a structured JSON format for content management. See `data/default-content.json` for the complete schema.

Main sections include:
- Navigation
- Hero
- About
- Services
- Community Programs
- Testimonials
- Get Involved
- Contact
- Footer
- Team
- Blog

## Troubleshooting

### Theme doesn't display properly

1. Make sure you're running PHP 8.3 or higher
2. Check that the build assets are present in `/assets/build/`
3. Clear your browser cache and WordPress cache

### Content changes don't appear

1. Go to In Step Content admin page
2. Verify your changes are saved
3. Clear browser cache
4. Check browser console for JavaScript errors

### Performance Issues

1. Enable a caching plugin (WP Super Cache, W3 Total Cache)
2. Optimize images before uploading
3. Use a CDN for static assets

## Development

If you need to rebuild the React application:

1. Install dependencies: `npm install`
2. Build for WordPress: `npm run build:wordpress`
3. Assets will be generated in `wordpress/wp-plugin/instep-community-connect/assets/build/`
4. Copy to theme: `cp -r wordpress/wp-plugin/instep-community-connect/assets/build wordpress-theme/instep-community-connect/assets/`

## Support

For support, please contact the In Step Community Connect Team.

## Credits

- Built with React, TypeScript, and Vite
- UI Components: Radix UI, shadcn/ui
- Styling: Tailwind CSS
- Icons: Lucide React

## License

This theme is licensed under the GPL-2.0-or-later license.

## Changelog

### Version 1.0.0
- Initial release
- React-based single-page application
- WordPress admin integration
- RESTful API
- Responsive design
- PHP 8.3 support
- Accessibility features
