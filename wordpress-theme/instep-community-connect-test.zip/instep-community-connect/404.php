<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package InStepCommunityConnect
 * @since 1.0.0
 */

get_header();
?>

<div id="instep-community-connect-root"></div>

<?php
get_footer();
