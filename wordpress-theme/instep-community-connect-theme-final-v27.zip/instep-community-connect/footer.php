<?php
/**
 * The footer for our theme
 *
 * @package InStepCommunityConnect
 * @since 1.0.0
 */
?>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
