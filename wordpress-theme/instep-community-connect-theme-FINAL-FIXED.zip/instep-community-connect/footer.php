<?php
/**
 * The footer for our theme
 *
 * @package InStepCommunityConnect
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
